param(
    [string]$ProjectPath="D:\projects\elevate_her"
)

$ErrorActionPreference="Stop"
Set-Location $ProjectPath

$utf8 = New-Object System.Text.UTF8Encoding($false)

Write-Host "Applying ElevateHer360 universal admin UX + Courses..." -ForegroundColor Cyan


# ----------------------------------------------------------
# 1. Force full admin Blade pages onto layouts.admin
# ----------------------------------------------------------

$adminViews = Join-Path $ProjectPath "resources\views\admin"

Get-ChildItem $adminViews -Recurse -Filter "*.blade.php" | ForEach-Object {

    if (
        $_.FullName -match "\\partials\\" -or
        $_.FullName -match "\\components\\"
    ) {
        return
    }

    $text = [IO.File]::ReadAllText($_.FullName)
    $updated = $text

    $updated = $updated.Replace(
        "@extends('layouts.app')",
        "@extends('layouts.admin')"
    )

    $updated = $updated.Replace(
        '@extends("layouts.app")',
        '@extends("layouts.admin")'
    )

    $updated = $updated.Replace(
        "@extends('layouts.public')",
        "@extends('layouts.admin')"
    )

    $updated = $updated.Replace(
        '@extends("layouts.public")',
        '@extends("layouts.admin")'
    )

    if (
        $updated -notmatch "@extends\(" -and
        $updated -match "@section\(['""]content['""]\)"
    ) {
        $updated =
            "@extends('layouts.admin')`r`n" +
            $updated
    }

    if ($updated -ne $text) {
        [IO.File]::WriteAllText(
            $_.FullName,
            $updated,
            $utf8
        )

        Write-Host (
            "SIDEBAR  " +
            $_.FullName.Replace(
                $ProjectPath + "\",
                ""
            )
        ) -ForegroundColor Green
    }
}


# ----------------------------------------------------------
# 2. Add universal responsive stylesheet
# ----------------------------------------------------------

$cssPath = Join-Path $ProjectPath "resources\css\app.css"
$css = [IO.File]::ReadAllText($cssPath)

if (
    $css -notmatch
    "admin-universal-responsive.css"
) {
    $css =
        "@import './admin-universal-responsive.css';`r`n" +
        $css

    [IO.File]::WriteAllText(
        $cssPath,
        $css,
        $utf8
    )
}


# ----------------------------------------------------------
# 3. Add universal admin JavaScript
# ----------------------------------------------------------

$jsPath = Join-Path $ProjectPath "resources\js\app.js"
$js = [IO.File]::ReadAllText($jsPath)

if (
    $js -notmatch
    "admin-universal-responsive"
) {
    $js +=
        "`r`nimport './admin-universal-responsive';`r`n"

    [IO.File]::WriteAllText(
        $jsPath,
        $js,
        $utf8
    )
}


# ----------------------------------------------------------
# 4. Upgrade Courses routes:
#    - restore destroy route
#    - add bulk delete
# ----------------------------------------------------------

$phase3 = Join-Path $ProjectPath "routes\web.phase3.php"

if (Test-Path $phase3) {

    $routes =
        [IO.File]::ReadAllText($phase3)

    $resourceOld =
        "Route::resource('courses',CourseController::class)->except(['show','destroy'])"

    $resourceNew =
        "Route::resource('courses',CourseController::class)->except(['show'])"

    $routes =
        $routes.Replace(
            $resourceOld,
            $resourceNew
        )

    if (
        $routes -notmatch
        "courses\.bulk-destroy"
    ) {

        $needle =
            "        Route::resource('courses',CourseController::class)->except(['show'])"

        $insert =
            "        Route::delete('/courses/bulk-delete',[CourseController::class,'bulkDestroy'])" +
            "`r`n            ->middleware('permission:courses.delete')->name('courses.bulk-destroy');" +
            "`r`n`r`n" +
            $needle

        $routes =
            $routes.Replace(
                $needle,
                $insert
            )
    }

    [IO.File]::WriteAllText(
        $phase3,
        $routes,
        $utf8
    )
}


# ----------------------------------------------------------
# 5. Remove duplicate legacy admin dashboard view route
# ----------------------------------------------------------

$phase2 = Join-Path $ProjectPath "routes\web.phase2.php"

if (Test-Path $phase2) {

    $routes2 =
        [IO.File]::ReadAllText($phase2)

    $routes2 =
        [regex]::Replace(
            $routes2,
            "\s*Route::view\('/dashboard',\s*'admin\.dashboard'\)->name\('dashboard'\);\r?\n",
            "`r`n"
        )

    [IO.File]::WriteAllText(
        $phase2,
        $routes2,
        $utf8
    )
}


# ----------------------------------------------------------
# 6. Clear caches / build / diagnostics
# ----------------------------------------------------------

Write-Host ""
Write-Host "Clearing Laravel caches..." -ForegroundColor Cyan

php artisan view:clear
php artisan optimize:clear


Write-Host ""
Write-Host "Checking Courses routes..." -ForegroundColor Cyan

php artisan route:list --name=admin.elearning.courses


Write-Host ""
Write-Host "Checking admin pages still using layouts.app..." -ForegroundColor Cyan

$remaining =
    Get-ChildItem $adminViews -Recurse -Filter "*.blade.php" |
    Select-String -Pattern "@extends\(['""]layouts\.app['""]\)"

if ($remaining) {

    $remaining | ForEach-Object {
        Write-Host $_.Path -ForegroundColor Red
    }

}
else {

    Write-Host "None" -ForegroundColor Green

}


Write-Host ""
Write-Host "Building responsive frontend..." -ForegroundColor Cyan

npm run build


Write-Host ""
Write-Host "Running tests..." -ForegroundColor Cyan

php artisan test


Write-Host ""
Write-Host "DONE." -ForegroundColor Green
Write-Host "Admin pages now inherit the sidebar and universal responsive behaviour." -ForegroundColor Green
Write-Host "Courses now has its full admin page with modal CRUD, statistics, filters, multi-select and pagination." -ForegroundColor Green
Write-Host "Hard refresh with Ctrl+F5." -ForegroundColor Yellow
