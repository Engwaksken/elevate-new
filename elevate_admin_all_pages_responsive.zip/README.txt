ELEVATEHER360 - UNIVERSAL ADMIN UX + COURSES

PURPOSE
This batch extends the admin standard across the entire administration area and restores/develops the missing Courses page.

WHAT IT APPLIES GLOBALLY
- all full resources/views/admin/**/*.blade.php pages use layouts.admin
- sidebar becomes the shared administration navigation
- filter/search forms stay on one row on desktop
- filters wrap cleanly on tablets
- controls stack to one column on narrow phones
- all admin tables gain responsive horizontal scrolling
- existing create/edit page links under /admin are progressively opened inside a modal
- existing DELETE forms receive a proper confirmation modal
- simple CRUD tables with delete actions automatically gain row selection and bulk-delete support
- admin pages without module-specific stats receive truthful rendered-page stats:
  * records on the current rendered page
  * active URL filters
  * current page
  * selected rows
- simple tables without their own search get an on-page search fallback
- tables without server pagination get a client pagination fallback when they contain more than 15 rendered rows

IMPORTANT ABOUT GLOBAL FALLBACKS
The auto-generated statistics/search/pagination are based on the records currently rendered in the browser. Pages with proper module-specific server statistics and filters continue using those instead.

COURSES FULL DEVELOPMENT
The Courses page is upgraded to:
- sidebar layout
- Total / Published / Draft / Archived statistics
- title/code/summary search
- programme filter
- project filter
- branch filter
- delivery mode filter
- status filter
- Today / This week / This month / This quarter / This year filter
- custom From / To date filter
- 10 / 20 / 25 / 50 / 100 rows per page
- pagination
- multiple selection
- bulk delete
- Create Course modal
- Edit Course modal
- Delete Course modal
- placeholders and hints
- responsive modal forms
- responsive table
- self-enrolment setting
- delivery mode
- duration
- pass mark
- status
- summary and full description

INSTALL
1. Create a checkpoint:
   cd D:\projects\elevate_her
   git add .
   git commit -m "Checkpoint before universal admin UX"

2. Extract this ZIP directly into:
   D:\projects\elevate_her
   Choose Replace files in destination.

3. Run:
   cd D:\projects\elevate_her
   Unblock-File .\APPLY_ADMIN_ALL_PAGES_RESPONSIVE.ps1
   powershell -ExecutionPolicy Bypass -File .\APPLY_ADMIN_ALL_PAGES_RESPONSIVE.ps1

4. Hard refresh:
   Ctrl + F5

VERIFY
- /admin/dashboard
- /admin/users
- /admin/programmes
- /admin/projects
- /admin/branches
- /admin/cohorts
- /admin/elearning/courses
- /admin/migrations
- /admin/roles
- /admin/workplans
- /admin/indicators
- /admin/meal
- /admin/tasks
- /admin/deliverables
- /admin/hr/employees
- /admin/hr/leave
- /admin/hr/appraisals
- /admin/hr/exits
- /admin/procurement/suppliers
- /admin/procurement/requests
- /admin/procurement/purchase-orders
- /admin/assets

WORKFLOW-SPECIFIC PAGES
Workplans, MEAL, HR, Procurement, Assets and similar modules have actions such as approve, submit, assign, receive, verify, complete and dispose. The universal modal layer preserves those workflow routes instead of rewriting them into unsafe generic CRUD operations.
