@extends('layouts.admin')

@section('title','Courses | ElevateHer360 Administration')

@section('content')

<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Programme Delivery</span>
        <h1>Courses</h1>
        <p>Manage learning courses, delivery settings, enrolment options and publishing status.</p>
    </div>

    <div class="admin-page-actions">
        <button
            type="button"
            class="btn btn-primary"
            data-modal-open="createCourseModal"
        >
            <i class="fas fa-plus"></i>
            New Course
        </button>
    </div>
</div>


<div class="admin-stats-grid compact">

    @foreach([
        ['total','Total Courses','fa-graduation-cap'],
        ['published','Published','fa-circle-check'],
        ['draft','Draft','fa-pen-ruler'],
        ['archived','Archived','fa-box-archive'],
    ] as [$key,$label,$icon])

        <div class="admin-stat">

            <span class="admin-stat-icon">
                <i class="fas {{ $icon }}"></i>
            </span>

            <div>
                <small>{{ $label }}</small>
                <strong>{{ number_format($stats[$key] ?? 0) }}</strong>
            </div>

        </div>

    @endforeach

</div>


<div class="admin-panel">

    <form method="GET" class="admin-toolbar admin-toolbar-one-row">

        <div class="search-box">
            <i class="fas fa-magnifying-glass"></i>

            <input
                name="search"
                value="{{ request('search') }}"
                placeholder="Search course title, code or summary..."
            >
        </div>


        <select name="programme_id" aria-label="Programme filter">
            <option value="">All programmes</option>

            @foreach($programmes as $programme)
                <option
                    value="{{ $programme->id }}"
                    @selected(
                        (string)request('programme_id') ===
                        (string)$programme->id
                    )
                >
                    {{ $programme->name }}
                </option>
            @endforeach
        </select>


        <select name="project_id" aria-label="Project filter">
            <option value="">All projects</option>

            @foreach($projects as $project)
                <option
                    value="{{ $project->id }}"
                    @selected(
                        (string)request('project_id') ===
                        (string)$project->id
                    )
                >
                    {{ $project->name }}
                </option>
            @endforeach
        </select>


        <select name="branch_id" aria-label="Branch filter">
            <option value="">All branches</option>

            @foreach($branches as $branch)
                <option
                    value="{{ $branch->id }}"
                    @selected(
                        (string)request('branch_id') ===
                        (string)$branch->id
                    )
                >
                    {{ $branch->name }}
                </option>
            @endforeach
        </select>


        <select name="delivery_mode" aria-label="Delivery mode filter">
            <option value="">All delivery</option>

            @foreach([
                'online' => 'Online',
                'in_person' => 'In person',
                'blended' => 'Blended',
            ] as $value => $label)

                <option
                    value="{{ $value }}"
                    @selected(
                        request('delivery_mode') === $value
                    )
                >
                    {{ $label }}
                </option>

            @endforeach
        </select>


        <select name="status" aria-label="Status filter">
            <option value="">All statuses</option>

            @foreach([
                'draft' => 'Draft',
                'published' => 'Published',
                'archived' => 'Archived',
            ] as $value => $label)

                <option
                    value="{{ $value }}"
                    @selected(request('status') === $value)
                >
                    {{ $label }}
                </option>

            @endforeach
        </select>


        <select name="period" aria-label="Period filter">
            <option value="">All periods</option>

            @foreach([
                'today' => 'Today',
                'week' => 'This week',
                'month' => 'This month',
                'quarter' => 'This quarter',
                'year' => 'This year',
            ] as $value => $label)

                <option
                    value="{{ $value }}"
                    @selected(request('period') === $value)
                >
                    {{ $label }}
                </option>

            @endforeach
        </select>


        <input
            type="date"
            class="date-input"
            name="from_date"
            value="{{ request('from_date') }}"
            aria-label="From date"
        >

        <input
            type="date"
            class="date-input"
            name="to_date"
            value="{{ request('to_date') }}"
            aria-label="To date"
        >


        <select name="per_page" aria-label="Rows per page">

            @foreach([10,20,25,50,100] as $size)

                <option
                    value="{{ $size }}"
                    @selected(
                        (int)request('per_page',20) === $size
                    )
                >
                    {{ $size }}/page
                </option>

            @endforeach

        </select>


        <button class="btn btn-primary btn-sm">
            <i class="fas fa-filter"></i>
            Apply
        </button>


        <a
            href="{{ route('admin.elearning.courses.index') }}"
            class="btn btn-outline btn-sm"
        >
            <i class="fas fa-rotate-left"></i>
            Reset
        </a>

    </form>


    <div
        id="courseBulkBar"
        class="admin-bulk-bar"
    >

        <strong>
            <span data-selected-count>0</span>
            selected
        </strong>


        <form
            method="POST"
            action="{{ route('admin.elearning.courses.bulk-destroy') }}"
            data-bulk-form
            data-table="coursesTable"
        >
            @csrf
            @method('DELETE')

            <button class="btn btn-danger btn-sm">
                <i class="fas fa-trash"></i>
                Delete Selected
            </button>

        </form>

    </div>


    <div class="admin-table-wrap">

        <table
            class="admin-table"
            id="coursesTable"
        >

            <thead>
            <tr>
                <th class="select-col">
                    <input
                        type="checkbox"
                        data-select-all
                        data-bulk-target="#courseBulkBar"
                    >
                </th>

                <th>Course</th>
                <th>Programme / Project</th>
                <th>Delivery</th>
                <th>Period</th>
                <th>Pass Mark</th>
                <th>Status</th>
                <th class="table-actions">Actions</th>
            </tr>
            </thead>


            <tbody>

            @forelse($courses as $course)

                <tr>

                    <td>
                        <input
                            type="checkbox"
                            data-row-select
                            value="{{ $course->id }}"
                        >
                    </td>


                    <td>
                        <strong>{{ $course->title }}</strong>

                        <small class="admin-cell-hint">
                            {{ $course->code ?: 'No code' }}
                        </small>
                    </td>


                    <td>
                        {{ optional($course->programme)->name ?: '—' }}

                        <small class="admin-cell-hint">
                            {{ optional($course->project)->name ?: '' }}
                        </small>
                    </td>


                    <td>
                        {{ ucfirst(str_replace('_',' ',$course->delivery_mode)) }}

                        @if($course->self_enrolment_enabled)
                            <small class="admin-cell-hint">
                                Self-enrolment enabled
                            </small>
                        @endif
                    </td>


                    <td>
                        {{ optional($course->start_date)->format('d M Y') ?: '—' }}
                        —
                        {{ optional($course->end_date)->format('d M Y') ?: '—' }}
                    </td>


                    <td>
                        {{ number_format((float)$course->pass_mark,0) }}%
                    </td>


                    <td>
                        <span class="status-chip {{ $course->status }}">
                            {{ ucfirst($course->status) }}
                        </span>
                    </td>


                    <td class="table-actions">

                        <div class="action-group">

                            <button
                                type="button"
                                class="btn-icon"
                                title="Edit course"
                                data-modal-open="editCourse{{ $course->id }}"
                            >
                                <i class="fas fa-pen"></i>
                            </button>


                            <button
                                type="button"
                                class="btn-icon danger"
                                title="Delete course"
                                data-modal-open="deleteCourse{{ $course->id }}"
                            >
                                <i class="fas fa-trash"></i>
                            </button>

                        </div>

                    </td>

                </tr>

            @empty

                <tr>
                    <td colspan="8">
                        <div class="admin-empty">
                            <i class="fas fa-graduation-cap"></i>
                            <strong>No courses found</strong>
                            <span>
                                Change the filters or create a new course.
                            </span>
                        </div>
                    </td>
                </tr>

            @endforelse

            </tbody>

        </table>

    </div>


    <div class="admin-pagination">
        {{ $courses->links() }}
    </div>

</div>



{{-- CREATE COURSE --}}
<div
    class="eh-modal"
    id="createCourseModal"
    aria-hidden="true"
>

    <div class="eh-modal-dialog eh-modal-lg">

        <div class="eh-modal-header">

            <div>
                <h2>New Course</h2>
                <p>
                    Create a learning course without leaving
                    the courses page.
                </p>
            </div>

            <button
                type="button"
                class="eh-modal-close"
                data-modal-close
            >
                <i class="fas fa-xmark"></i>
            </button>

        </div>


        <form
            method="POST"
            action="{{ route('admin.elearning.courses.store') }}"
        >

            @csrf

            <div class="eh-modal-body">

                <div class="modal-grid">

                    <div class="form-group">
                        <label>Course title *</label>

                        <input
                            name="title"
                            required
                            placeholder="e.g. Digital Marketing Fundamentals"
                        >

                        <small class="form-hint">
                            Enter the title participants will see.
                        </small>
                    </div>


                    <div class="form-group">
                        <label>Course code</label>

                        <input
                            name="code"
                            placeholder="e.g. DMF-101"
                        >

                        <small class="form-hint">
                            Optional unique short reference.
                        </small>
                    </div>


                    <div class="form-group">
                        <label>Programme</label>

                        <select name="programme_id">
                            <option value="">Select programme</option>

                            @foreach($programmes as $programme)
                                <option value="{{ $programme->id }}">
                                    {{ $programme->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Project</label>

                        <select name="project_id">
                            <option value="">Select project</option>

                            @foreach($projects as $project)
                                <option value="{{ $project->id }}">
                                    {{ $project->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Branch</label>

                        <select name="branch_id">
                            <option value="">All / no specific branch</option>

                            @foreach($branches as $branch)
                                <option value="{{ $branch->id }}">
                                    {{ $branch->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Delivery mode *</label>

                        <select
                            name="delivery_mode"
                            required
                        >
                            <option value="online">Online</option>
                            <option value="in_person">In person</option>
                            <option value="blended">Blended</option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Start date</label>

                        <input
                            type="date"
                            name="start_date"
                        >
                    </div>


                    <div class="form-group">
                        <label>End date</label>

                        <input
                            type="date"
                            name="end_date"
                        >
                    </div>


                    <div class="form-group">
                        <label>Duration hours</label>

                        <input
                            type="number"
                            min="1"
                            name="duration_hours"
                            placeholder="e.g. 24"
                        >
                    </div>


                    <div class="form-group">
                        <label>Pass mark % *</label>

                        <input
                            type="number"
                            min="0"
                            max="100"
                            step="0.01"
                            name="pass_mark"
                            value="50"
                            required
                            placeholder="e.g. 50"
                        >
                    </div>


                    <div class="form-group">
                        <label>Status *</label>

                        <select
                            name="status"
                            required
                        >
                            <option value="draft">Draft</option>
                            <option value="published">Published</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label class="modal-check">
                            <input
                                type="checkbox"
                                name="self_enrolment_enabled"
                                value="1"
                            >

                            <span>
                                Allow participant self-enrolment
                            </span>
                        </label>

                        <small class="form-hint">
                            Participants can enrol themselves where
                            programme rules allow it.
                        </small>
                    </div>


                    <div class="form-group full">
                        <label>Summary</label>

                        <textarea
                            name="summary"
                            placeholder="Add a short course summary for listings and participant discovery..."
                        ></textarea>
                    </div>


                    <div class="form-group full">
                        <label>Description</label>

                        <textarea
                            name="description"
                            rows="6"
                            placeholder="Describe the course objectives, content, audience and expected learning outcomes..."
                        ></textarea>
                    </div>

                </div>

            </div>


            <div class="eh-modal-footer">

                <button
                    type="button"
                    class="btn btn-outline"
                    data-modal-close
                >
                    Cancel
                </button>

                <button class="btn btn-primary">
                    <i class="fas fa-floppy-disk"></i>
                    Create Course
                </button>

            </div>

        </form>

    </div>

</div>



{{-- EDIT + DELETE --}}
@foreach($courses as $course)

    <div
        class="eh-modal"
        id="editCourse{{ $course->id }}"
        aria-hidden="true"
    >

        <div class="eh-modal-dialog eh-modal-lg">

            <div class="eh-modal-header">

                <div>
                    <h2>Edit Course</h2>
                    <p>{{ $course->title }}</p>
                </div>

                <button
                    type="button"
                    class="eh-modal-close"
                    data-modal-close
                >
                    <i class="fas fa-xmark"></i>
                </button>

            </div>


            <form
                method="POST"
                action="{{ route('admin.elearning.courses.update',$course) }}"
            >

                @csrf
                @method('PUT')

                <div class="eh-modal-body">

                    <div class="modal-grid">

                        <div class="form-group">
                            <label>Course title *</label>

                            <input
                                name="title"
                                value="{{ $course->title }}"
                                required
                            >
                        </div>


                        <div class="form-group">
                            <label>Course code</label>

                            <input
                                name="code"
                                value="{{ $course->code }}"
                            >
                        </div>


                        <div class="form-group">
                            <label>Programme</label>

                            <select name="programme_id">
                                <option value="">Select programme</option>

                                @foreach($programmes as $programme)
                                    <option
                                        value="{{ $programme->id }}"
                                        @selected(
                                            $course->programme_id ===
                                            $programme->id
                                        )
                                    >
                                        {{ $programme->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>


                        <div class="form-group">
                            <label>Project</label>

                            <select name="project_id">
                                <option value="">Select project</option>

                                @foreach($projects as $project)
                                    <option
                                        value="{{ $project->id }}"
                                        @selected(
                                            $course->project_id ===
                                            $project->id
                                        )
                                    >
                                        {{ $project->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>


                        <div class="form-group">
                            <label>Branch</label>

                            <select name="branch_id">
                                <option value="">All / no specific branch</option>

                                @foreach($branches as $branch)
                                    <option
                                        value="{{ $branch->id }}"
                                        @selected(
                                            $course->branch_id ===
                                            $branch->id
                                        )
                                    >
                                        {{ $branch->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>


                        <div class="form-group">
                            <label>Delivery mode *</label>

                            <select
                                name="delivery_mode"
                                required
                            >
                                @foreach([
                                    'online' => 'Online',
                                    'in_person' => 'In person',
                                    'blended' => 'Blended',
                                ] as $value => $label)

                                    <option
                                        value="{{ $value }}"
                                        @selected(
                                            $course->delivery_mode ===
                                            $value
                                        )
                                    >
                                        {{ $label }}
                                    </option>

                                @endforeach
                            </select>
                        </div>


                        <div class="form-group">
                            <label>Start date</label>

                            <input
                                type="date"
                                name="start_date"
                                value="{{ optional($course->start_date)->format('Y-m-d') }}"
                            >
                        </div>


                        <div class="form-group">
                            <label>End date</label>

                            <input
                                type="date"
                                name="end_date"
                                value="{{ optional($course->end_date)->format('Y-m-d') }}"
                            >
                        </div>


                        <div class="form-group">
                            <label>Duration hours</label>

                            <input
                                type="number"
                                min="1"
                                name="duration_hours"
                                value="{{ $course->duration_hours }}"
                            >
                        </div>


                        <div class="form-group">
                            <label>Pass mark % *</label>

                            <input
                                type="number"
                                min="0"
                                max="100"
                                step="0.01"
                                name="pass_mark"
                                value="{{ $course->pass_mark }}"
                                required
                            >
                        </div>


                        <div class="form-group">
                            <label>Status *</label>

                            <select
                                name="status"
                                required
                            >
                                @foreach([
                                    'draft' => 'Draft',
                                    'published' => 'Published',
                                    'archived' => 'Archived',
                                ] as $value => $label)

                                    <option
                                        value="{{ $value }}"
                                        @selected($course->status === $value)
                                    >
                                        {{ $label }}
                                    </option>

                                @endforeach
                            </select>
                        </div>


                        <div class="form-group">
                            <label class="modal-check">

                                <input
                                    type="checkbox"
                                    name="self_enrolment_enabled"
                                    value="1"
                                    @checked(
                                        $course->self_enrolment_enabled
                                    )
                                >

                                <span>
                                    Allow participant self-enrolment
                                </span>

                            </label>
                        </div>


                        <div class="form-group full">
                            <label>Summary</label>

                            <textarea name="summary">{{ $course->summary }}</textarea>
                        </div>


                        <div class="form-group full">
                            <label>Description</label>

                            <textarea
                                name="description"
                                rows="6"
                            >{{ $course->description }}</textarea>
                        </div>

                    </div>

                </div>


                <div class="eh-modal-footer">

                    <button
                        type="button"
                        class="btn btn-outline"
                        data-modal-close
                    >
                        Cancel
                    </button>

                    <button class="btn btn-primary">
                        <i class="fas fa-floppy-disk"></i>
                        Save Changes
                    </button>

                </div>

            </form>

        </div>

    </div>


    <div
        class="eh-modal"
        id="deleteCourse{{ $course->id }}"
        aria-hidden="true"
    >

        <div class="eh-modal-dialog">

            <div class="eh-modal-header">

                <div>
                    <h2>Delete Course?</h2>
                    <p>This action cannot be undone.</p>
                </div>

                <button
                    type="button"
                    class="eh-modal-close"
                    data-modal-close
                >
                    <i class="fas fa-xmark"></i>
                </button>

            </div>


            <div class="eh-modal-body">

                <p>
                    Delete
                    <strong>{{ $course->title }}</strong>?
                    Existing enrolments or learning records may
                    prevent deletion.
                </p>

            </div>


            <div class="eh-modal-footer">

                <button
                    type="button"
                    class="btn btn-outline"
                    data-modal-close
                >
                    Cancel
                </button>


                <form
                    method="POST"
                    action="{{ route('admin.elearning.courses.destroy',$course) }}"
                >

                    @csrf
                    @method('DELETE')

                    <button class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                        Delete Course
                    </button>

                </form>

            </div>

        </div>

    </div>

@endforeach

@endsection
