<?php

namespace App\Http\Controllers\Admin\Elearning;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use App\Models\Course;
use App\Models\Programme;
use App\Models\Project;
use App\Services\AuditService;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        $query = Course::query();

        if ($search = trim((string) $request->get('search'))) {
            $query->where(fn ($q) => $q
                ->where('title', 'like', "%{$search}%")
                ->orWhere('code', 'like', "%{$search}%")
                ->orWhere('summary', 'like', "%{$search}%"));
        }

        if ($status = $request->get('status')) {
            $query->where('status', $status);
        }

        if ($delivery = $request->get('delivery_mode')) {
            $query->where('delivery_mode', $delivery);
        }

        if ($programmeId = $request->get('programme_id')) {
            $query->where('programme_id', $programmeId);
        }

        if ($projectId = $request->get('project_id')) {
            $query->where('project_id', $projectId);
        }

        if ($branchId = $request->get('branch_id')) {
            $query->where('branch_id', $branchId);
        }

        $this->applyPeriod($query, $request);

        $stats = [
            'total' => Course::count(),
            'published' => Course::where('status', 'published')->count(),
            'draft' => Course::where('status', 'draft')->count(),
            'archived' => Course::where('status', 'archived')->count(),
        ];

        $perPage = in_array((int) $request->get('per_page'), [10,15,25,50,100], true)
            ? (int) $request->get('per_page')
            : 20;

        return view('admin.elearning.courses.index', [
            'courses' => $query->latest()->paginate($perPage)->withQueryString(),
            'programmes' => Programme::orderBy('name')->get(),
            'projects' => Project::orderBy('name')->get(),
            'branches' => Branch::where('is_active', true)->orderBy('name')->get(),
            'stats' => $stats,
        ]);
    }

    public function create()
    {
        return redirect()
            ->route('admin.elearning.courses.index')
            ->with('info', 'Use the New Course button.');
    }

    public function store(Request $request, AuditService $audit)
    {
        $course = Course::create(
            $this->validated($request) + ['created_by' => auth()->id()]
        );

        $audit->log('courses', 'created', $course, [], $course->toArray());

        return back()->with('success', 'Course created successfully.');
    }

    public function edit(Course $course)
    {
        return redirect()
            ->route('admin.elearning.courses.index')
            ->with('info', 'Use the Edit action on the course row.');
    }

    public function update(Request $request, Course $course, AuditService $audit)
    {
        $old = $course->toArray();

        $course->update(
            $this->validated($request, $course->id)
        );

        $audit->log(
            'courses',
            'updated',
            $course,
            $old,
            $course->fresh()->toArray()
        );

        return back()->with('success', 'Course updated successfully.');
    }

    public function destroy(Course $course, AuditService $audit)
    {
        $old = $course->toArray();
        $course->delete();

        $audit->log('courses', 'deleted', null, $old, []);

        return back()->with('success', 'Course deleted successfully.');
    }

    public function bulkDestroy(Request $request, AuditService $audit)
    {
        $data = $request->validate([
            'ids' => ['required','array','min:1'],
            'ids.*' => ['integer','exists:courses,id'],
        ]);

        $items = Course::whereKey($data['ids'])->get();

        foreach ($items as $course) {
            $old = $course->toArray();
            $course->delete();
            $audit->log('courses', 'deleted', null, $old, []);
        }

        return back()->with(
            'success',
            $items->count().' course(s) deleted.'
        );
    }

    private function validated(Request $request, ?int $id = null): array
    {
        return $request->validate([
            'programme_id' => ['nullable','exists:programmes,id'],
            'project_id' => ['nullable','exists:projects,id'],
            'branch_id' => ['nullable','exists:branches,id'],
            'title' => ['required','string','max:190'],
            'code' => ['nullable','string','max:50','unique:courses,code,'.($id ?? 'NULL')],
            'summary' => ['nullable','string','max:1000'],
            'description' => ['nullable','string'],
            'delivery_mode' => ['required','in:online,in_person,blended'],
            'start_date' => ['nullable','date'],
            'end_date' => ['nullable','date','after_or_equal:start_date'],
            'duration_hours' => ['nullable','integer','min:1'],
            'pass_mark' => ['required','numeric','min:0','max:100'],
            'self_enrolment_enabled' => ['nullable','boolean'],
            'status' => ['required','in:draft,published,archived'],
        ]) + [
            'self_enrolment_enabled' => $request->boolean('self_enrolment_enabled'),
        ];
    }

    private function applyPeriod($query, Request $request): void
    {
        $now = now();

        match ($request->get('period')) {
            'today' => $query->whereDate('created_at', $now->toDateString()),
            'week' => $query->whereBetween('created_at', [
                $now->copy()->startOfWeek(),
                $now->copy()->endOfWeek(),
            ]),
            'month' => $query->whereBetween('created_at', [
                $now->copy()->startOfMonth(),
                $now->copy()->endOfMonth(),
            ]),
            'quarter' => $query->whereBetween('created_at', [
                $now->copy()->firstOfQuarter(),
                $now->copy()->lastOfQuarter(),
            ]),
            'year' => $query->whereYear('created_at', $now->year),
            default => null,
        };

        if ($from = $request->get('from_date')) {
            $query->whereDate('created_at', '>=', $from);
        }

        if ($to = $request->get('to_date')) {
            $query->whereDate('created_at', '<=', $to);
        }
    }
}
